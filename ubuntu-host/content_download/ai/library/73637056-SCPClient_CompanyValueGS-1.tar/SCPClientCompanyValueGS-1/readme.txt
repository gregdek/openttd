SCPClient_CompanyValueGS
========================

This library includes a Script Communication Protocol Client for AIs to be
able to play in a game running the Company Value GS game script with SCP
enabled.


-- API docs --
See main.nut of the library which have commented public members for more
details.

IsCompanyValueGSGame() - ret: bool
IsCompanyValueGSInGoalMode() - ret: bool
IsCompanyValueGSInRankingMode() - ret: bool
GetBestCompanyID() - ret: CompanyID
GetBestCompanyValue() - ret: integer (£)
GetCurrentTargetValue() - ret: integer (£)
RankingList() - ret: AIList (CompanyID, integer (£)) value sorted
GetCompanyIDRank(company_id) - par: CompanyID; ret: integer (#)
GetCompanyIDValue(company_id) - par: CompanyID; ret: integer (£)
GetCompanyIDDiffToTarget(company_id) - par: CompanyID; ret: integer (£)
GetCompanyIDDiffToBest(company_id) - par: CompanyID; ret: integer (£)
GetCompanyIDDiffToNext(company_id, next) - par: CompanyID, bool; ret: integer (£)


-- Library design idea --
The idea is that other GSes may provide SCPClient_<some other lib>, and 
that AIs will want to include more than one of them. Therefore this 
library does not initialize or include the SCP library. Instead you pass
an instance of it to the SCPClient constructor.
